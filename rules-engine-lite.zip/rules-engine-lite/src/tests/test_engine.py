from decision_engine.rule_evaluator import evaluate_rules

def test_review_logic():
    rules = {
        "pass_score": 200,
        "rules": [
            {"field": "transaction.amount", "operator": "<=", "value": 500000, "score": 100},
            {"field": "transaction.country", "operator": "!=", "value": "sanctioned", "score": 200},
            {"field": "customer.account_age_days", "operator": ">=", "value": 30, "score": 50},
        ],
    }
    payload = {
        "transaction": {"amount": 200000, "country": "USA"},
        "customer": {"account_age_days": 90},
    }
    result = evaluate_rules(rules, payload)
    assert result["decision"] == "PASS"

def test_mixed_outcomes_should_fail():
    rules = {
        "pass_score": 100,
        "rules": [
            {"field": "transaction.amount", "operator": "<=", "value": 500000, "score": 50},
            {"field": "transaction.country", "operator": "==", "value": "sanctioned", "score": -200},
            {"field": "customer.account_age_days", "operator": ">=", "value": 30, "score": 20},
        ],
    }
    payload = {
        "transaction": {"amount": 300000, "country": "SANCTIONED"},
        "customer": {"account_age_days": 40},
    }
    result = evaluate_rules(rules, payload)
    assert result["decision"] == "FAIL"
