from __future__ import annotations
from typing import Any, Dict, List
import json
import operator
import logging
from pathlib import Path

LOG_FILE = Path("src/decision_engine/engine.log")
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    filename=str(LOG_FILE),
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("rules_engine")

OP_MAP = {
    ">=": operator.ge,
    "<=": operator.le,
    ">": operator.gt,
    "<": operator.lt,
    "==": operator.eq,
    "!=": operator.ne,
}

def _summarize_rule(rule: dict) -> str:
    return f"{rule.get('field')} {rule.get('operator')} {rule.get('value')}"

def _derive_review_threshold(score: int, pass_score: int) -> str:
    if score >= pass_score:
        return "PASS"
    elif score >= pass_score - 50:
        return "REVIEW"
    return "FAIL"

def get_nested_value(data: Dict[str, Any], field_path: str) -> Any | None:
    current = data
    for key in field_path.split("."):
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return None
    return current

def load_rules_from_json(filepath: str | Path) -> Dict[str, Any]:
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Rules file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))

def _format_explanation(score: int, pass_score: int,
                        trace: List[str], failed_rules: List[str]) -> Dict[str, Any]:
    status = _derive_review_threshold(score, pass_score)
    text = [f"Final decision: **{status}**"]
    if failed_rules:
        text.append("⚠ Risk factors detected:")
        text.extend([f"• {r}" for r in failed_rules])
    text.append(f"Score: {score} / Threshold: {pass_score}")
    return {"status": status, "text": "\n".join(text)}

def evaluate_rules(rule_set: Dict[str, Any],
                   payload: Dict[str, Any]) -> Dict[str, Any]:
    score = 0
    pass_score = rule_set.get("pass_score", 0)
    trace: List[str] = []
    failed_rules: List[str] = []

    for idx, rule in enumerate(rule_set.get("rules", []), start=1):
        summary = _summarize_rule(rule)
        field, operator_str = rule["field"], rule["operator"]
        value, rule_score = rule["value"], rule.get("score", 0)
        op_func = OP_MAP.get(operator_str)

        if not op_func:
            trace.append(f"Rule {idx}: Invalid operator '{operator_str}'")
            failed_rules.append(summary)
            continue

        payload_value = get_nested_value(payload, field)
        if payload_value is None:
            trace.append(f"Rule {idx}: Missing field '{field}'")
            failed_rules.append(summary)
            continue

        if isinstance(payload_value, str) and isinstance(value, str):
            payload_value, value = payload_value.lower(), value.lower()

        try:
            passed = op_func(payload_value, value)
        except Exception as e:
            trace.append(f"Rule {idx}: Evaluation error ({e})")
            failed_rules.append(summary)
            continue

        if passed:
            score += rule_score
            trace.append(f"Rule {idx}: {summary} (+{rule_score})")
        else:
            trace.append(f"Rule {idx}: {summary}")
            failed_rules.append(summary)

    decision = _derive_review_threshold(score, pass_score)
    explanation = _format_explanation(score, pass_score, trace, failed_rules)

    return {"decision": decision, "score": score, "trace": trace, "explanation": explanation}
