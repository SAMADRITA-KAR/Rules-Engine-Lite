from pathlib import Path
import argparse
import json
import sys

# Ensure project root (src) is importable when running as module
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from decision_engine.rule_evaluator import load_rules_from_json, evaluate_rules

def load_payload(path: str | Path) -> dict:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Payload file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))

def main(argv: list | None = None):
    parser = argparse.ArgumentParser(description="Rules Engine Lite – CLI Execution")
    parser.add_argument("--rules", required=True, help="Path to rules JSON file")
    parser.add_argument("--payload", required=True, help="Path to payload JSON file")
    args = parser.parse_args(argv)

    rules = load_rules_from_json(Path(args.rules))
    payload = load_payload(Path(args.payload))
    result = evaluate_rules(rules, payload)

    print("\nDecision:", result["decision"])
    print("Score:", result["score"])
    print("\nExplanation:")
    print(result["explanation"]["text"])
    print("\nTrace:")
    for t in result["trace"]:
        print(" -", t)

if __name__ == "__main__":
    main()
